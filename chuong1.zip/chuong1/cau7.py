a = "hello"
print(a);