print("Chao cac ban");
